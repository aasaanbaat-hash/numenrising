/* ============================================
   IMMERSIV — Main JavaScript
   Scroll animations, nav effects, interactions
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {

  // ============================================
  // NAV SCROLL EFFECT
  // ============================================
  const nav = document.getElementById('mainNav');

  const handleNavScroll = () => {
    if (window.scrollY > 60) {
      nav.classList.add('scrolled');
    } else {
      nav.classList.remove('scrolled');
    }
  };

  window.addEventListener('scroll', handleNavScroll, { passive: true });


  // ============================================
  // INTERSECTION OBSERVER — REVEAL ANIMATIONS
  // ============================================
  const revealElements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right');

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        // Unobserve after reveal to save performance
        revealObserver.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.12,
    rootMargin: '0px 0px -60px 0px'
  });

  revealElements.forEach((el) => {
    revealObserver.observe(el);
  });


  // ============================================
  // PARALLAX HERO IMAGE
  // ============================================
  const heroImg = document.querySelector('.hero-img');

  const handleParallax = () => {
    if (!heroImg) return;
    const scrollY = window.scrollY;
    const maxScroll = window.innerHeight;
    if (scrollY < maxScroll) {
      heroImg.style.transform = `scale(1) translateY(${scrollY * 0.25}px)`;
    }
  };

  window.addEventListener('scroll', handleParallax, { passive: true });


  // ============================================
  // SMOOTH SCROLL FOR ANCHOR LINKS
  // ============================================
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', (e) => {
      const targetId = anchor.getAttribute('href');
      if (targetId === '#') return;

      const target = document.querySelector(targetId);
      if (target) {
        e.preventDefault();
        const navHeight = nav.offsetHeight;
        const targetTop = target.getBoundingClientRect().top + window.scrollY - navHeight - 20;

        window.scrollTo({
          top: targetTop,
          behavior: 'smooth'
        });
      }
    });
  });


  // ============================================
  // FORM SUBMISSION
  // ============================================
  const form = document.getElementById('reserveForm');

  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      const submitBtn = form.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;

      submitBtn.textContent = 'Sending...';
      submitBtn.disabled = true;

      // Collect form data
      const formData = new FormData(form);
      const data = Object.fromEntries(formData.entries());

      // Build mailto link as fallback
      const subject = encodeURIComponent(`IMMERSIV Reservation — ${data.city || 'City TBD'}`);
      const body = encodeURIComponent(
        `Name: ${data.name}\nEmail: ${data.email}\nPhone: ${data.phone}\nCity: ${data.city}\nMessage: ${data.message || 'None'}`
      );

      // Try Formspree first, fallback to mailto
      try {
        const response = await fetch(form.action, {
          method: 'POST',
          body: JSON.stringify(data),
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }
        });

        if (response.ok) {
          showSuccessMessage(form);
        } else {
          // Fallback to mailto
          window.location.href = `mailto:thenumenproduction@gmail.com?subject=${subject}&body=${body}`;
          showSuccessMessage(form);
        }
      } catch (err) {
        // Fallback to mailto
        window.location.href = `mailto:thenumenproduction@gmail.com?subject=${subject}&body=${body}`;
        showSuccessMessage(form);
      }

      submitBtn.textContent = originalText;
      submitBtn.disabled = false;
    });
  }

  function showSuccessMessage(form) {
    const successDiv = document.createElement('div');
    successDiv.className = 'form-success';
    successDiv.innerHTML = `
      <div class="success-icon">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#13485c" stroke-width="1.5">
          <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
          <polyline points="22 4 12 14.01 9 11.01"/>
        </svg>
      </div>
      <h3>Your reservation request has been received.</h3>
      <p>Our team will be in touch within 24 hours to confirm your spot and share everything you need to know before your evening.</p>
    `;

    // Style the success message
    successDiv.style.cssText = `
      text-align: center;
      padding: 48px 32px;
      background: #fffdf5;
      border: 1px solid rgba(163, 193, 204, 0.4);
      border-radius: 4px;
      animation: fadeInUp 0.5s ease forwards;
    `;

    const successIcon = successDiv.querySelector('.success-icon');
    if (successIcon) {
      successIcon.style.cssText = 'margin-bottom: 20px; display: flex; justify-content: center;';
    }

    const successH3 = successDiv.querySelector('h3');
    if (successH3) {
      successH3.style.cssText = `
        font-family: 'Cormorant Garamond', serif;
        font-size: 1.4rem;
        font-weight: 400;
        color: #13485c;
        margin-bottom: 12px;
      `;
    }

    const successP = successDiv.querySelector('p');
    if (successP) {
      successP.style.cssText = `
        font-family: 'Jost', sans-serif;
        font-size: 0.9rem;
        font-weight: 300;
        line-height: 1.7;
        color: rgba(19, 72, 92, 0.7);
      `;
    }

    form.parentNode.replaceChild(successDiv, form);
  }


  // ============================================
  // INTRO STRIP MARQUEE EFFECT
  // ============================================
  const introStrip = document.querySelector('.intro-strip-inner');

  if (introStrip) {
    // Add subtle hover interaction
    introStrip.addEventListener('mouseenter', () => {
      introStrip.style.letterSpacing = '0.35em';
      introStrip.style.transition = 'letter-spacing 0.4s ease';
    });

    introStrip.addEventListener('mouseleave', () => {
      introStrip.style.letterSpacing = '0.25em';
    });
  }


  // ============================================
  // SCHEDULE CARD HOVER ENHANCEMENT
  // ============================================
  const scheduleCards = document.querySelectorAll('.schedule-card');

  scheduleCards.forEach((card) => {
    card.addEventListener('mouseenter', () => {
      scheduleCards.forEach((c) => {
        if (c !== card) {
          c.style.opacity = '0.6';
        }
      });
    });

    card.addEventListener('mouseleave', () => {
      scheduleCards.forEach((c) => {
        c.style.opacity = '1';
      });
    });
  });


  // ============================================
  // COUNTER ANIMATION FOR STATS (if any)
  // ============================================
  // Reserved for future use


  // ============================================
  // LAZY LOADING IMAGES
  // ============================================
  const images = document.querySelectorAll('img[data-src]');

  if (images.length > 0) {
    const imageObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
          imageObserver.unobserve(img);
        }
      });
    });

    images.forEach((img) => imageObserver.observe(img));
  }


  // ============================================
  // CURSOR TRAIL EFFECT (subtle)
  // ============================================
  // Removed for performance — keeping page fast


  // ============================================
  // HERO TEXT STAGGER
  // ============================================
  const heroElements = document.querySelectorAll('.hero-content .reveal');

  heroElements.forEach((el, index) => {
    el.style.animationDelay = `${0.3 + index * 0.15}s`;
    el.classList.add('visible');
  });

});


// ============================================
// PAGE LOAD TRANSITION
// ============================================
window.addEventListener('load', () => {
  document.body.style.opacity = '0';
  document.body.style.transition = 'opacity 0.5s ease';

  requestAnimationFrame(() => {
    document.body.style.opacity = '1';
  });
});
